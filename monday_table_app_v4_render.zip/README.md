
# The Monday Table – v4 (Render-ready)

This package contains **Render.com** deployment files.

## Deploy with Render (using render.yaml)
1. Push this folder to a new GitHub repo.
2. In Render, **New + → Blueprint** and point to your repo.
3. Render reads `render.yaml`, creates a **Web Service** with a **persistent disk** mounted at `/var/data`.
4. It will auto-generate `SECRET_KEY` and set `DATA_DIR=/var/data`.

**Start command** uses `gunicorn` and the Flask app object `app` from `app.py`.

## Local dev (optional)
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export FLASK_APP=app.py
flask run
```
