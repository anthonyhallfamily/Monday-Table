
from __future__ import annotations
import os
import sqlite3
import random
from datetime import datetime
from typing import Any, Tuple
import csv
from io import TextIOWrapper

from flask import Flask, g, render_template, request, redirect, url_for, flash, abort

# --- Config ---
CLUB_NAME = "The Monday Table"
MAX_FLIGHTS_PER_EVENT = 10
DATABASE_NAME = "monday_table.db"

app = Flask(__name__, instance_relative_config=True, static_folder='static', template_folder='templates')
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret')
app.config['MAX_CONTENT_LENGTH'] = 4 * 1024 * 1024  # 4MB upload cap

# Optional Render persistent disk mount via DATA_DIR
DATA_DIR = os.environ.get('DATA_DIR')
if DATA_DIR:
    os.makedirs(DATA_DIR, exist_ok=True)
    DB_PATH = os.path.join(DATA_DIR, DATABASE_NAME)
else:
    # Ensure instance folder exists for local/dev
    try:
        os.makedirs(app.instance_path, exist_ok=True)
    except OSError:
        pass
    DB_PATH = os.path.join(app.instance_path, DATABASE_NAME)

# --- Database helpers ---

def get_db() -> sqlite3.Connection:
    if 'db' not in g:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        g.db = conn
    return g.db

@app.teardown_appcontext
def close_db(exception: Exception | None):
    db = g.pop('db', None)
    if db is not None:
        db.close()

SCHEMA_SQL = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    event_date TEXT NOT NULL,
    event_time TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS event_attendees (
    event_id INTEGER NOT NULL,
    member_id INTEGER NOT NULL,
    PRIMARY KEY (event_id, member_id),
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS flights (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER NOT NULL,
    seq INTEGER NOT NULL,
    food TEXT,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    UNIQUE(event_id, seq)
);

CREATE TABLE IF NOT EXISTS wines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    flight_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    producer TEXT,
    vintage INTEGER,
    pour_seq INTEGER,
    FOREIGN KEY (flight_id) REFERENCES flights(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS scores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER NOT NULL,
    flight_id INTEGER NOT NULL,
    wine_id INTEGER NOT NULL,
    member_id INTEGER NOT NULL,
    score INTEGER NOT NULL CHECK(score BETWEEN 1 AND 10),
    comment TEXT,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    FOREIGN KEY (flight_id) REFERENCES flights(id) ON DELETE CASCADE,
    FOREIGN KEY (wine_id) REFERENCES wines(id) ON DELETE CASCADE,
    FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
    UNIQUE (wine_id, member_id)
);
"""

def init_db():
    db = get_db()
    db.executescript(SCHEMA_SQL)
    db.commit()


def migrate_db():
    """Light migrations for v2/v3/v4 columns."""
    db = get_db()
    # scores.comment (v2)
    cols = db.execute("PRAGMA table_info(scores)").fetchall()
    if 'comment' not in {c[1] for c in cols}:
        db.execute("ALTER TABLE scores ADD COLUMN comment TEXT")
        db.commit()
    # wines.vintage, wines.pour_seq (v3); wines.producer (v4)
    wcols = db.execute("PRAGMA table_info(wines)").fetchall()
    existing = {c[1] for c in wcols}
    if 'vintage' not in existing:
        db.execute("ALTER TABLE wines ADD COLUMN vintage INTEGER")
    if 'pour_seq' not in existing:
        db.execute("ALTER TABLE wines ADD COLUMN pour_seq INTEGER")
    if 'producer' not in existing:
        db.execute("ALTER TABLE wines ADD COLUMN producer TEXT")
    db.commit()

@app.before_request
def ensure_db():
    init_db()
    migrate_db()

# --- Utility functions ---

def query(db: sqlite3.Connection, sql: str, args: Tuple[Any, ...] = (), one: bool=False):
    cur = db.execute(sql, args)
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if one else rv

# --- Routes ---

@app.route('/')
def index():
    db = get_db()
    events = query(db, 'SELECT * FROM events ORDER BY datetime(event_date || " " || event_time) DESC')
    return render_template('index.html', club_name=CLUB_NAME, events=events)

@app.route('/event/new', methods=['GET', 'POST'])
def event_new():
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        event_date = request.form.get('event_date', '').strip()
        event_time = request.form.get('event_time', '').strip()
        if not title or not event_date or not event_time:
            flash('Please provide title, date, and time.', 'danger')
            return redirect(url_for('event_new'))
        try:
            datetime.strptime(event_date, '%Y-%m-%d')
            datetime.strptime(event_time, '%H:%M')
        except ValueError:
            flash('Invalid date or time format.', 'danger')
            return redirect(url_for('event_new'))
        db = get_db()
        db.execute('INSERT INTO events(title, event_date, event_time, created_at) VALUES(?, ?, ?, ?)',
                   (title, event_date, event_time, datetime.utcnow().isoformat()))
        db.commit()
        event_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]
        return redirect(url_for('event_overview', event_id=event_id))
    today = datetime.today().strftime('%Y-%m-%d')
    now = datetime.now().strftime('%H:%M')
    default_title = f"Tasting {today}"
    return render_template('event_new.html', club_name=CLUB_NAME, default_title=default_title, default_date=today, default_time=now)

@app.route('/event/<int:event_id>')
def event_overview(event_id: int):
    db = get_db()
    event = query(db, 'SELECT * FROM events WHERE id = ?', (event_id,), one=True)
    if not event:
        abort(404)
    flights = query(db, 'SELECT * FROM flights WHERE event_id = ? ORDER BY seq ASC', (event_id,))
    attendee_count = query(db, 'SELECT COUNT(*) as c FROM event_attendees WHERE event_id = ?', (event_id,), one=True)['c']
    return render_template('event_overview.html', club_name=CLUB_NAME, event=event, flights=flights, attendee_count=attendee_count, max_flights=MAX_FLIGHTS_PER_EVENT)

# --- Members & Import ---
@app.route('/members', methods=['GET', 'POST'])
def members():
    db = get_db()
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        if name:
            try:
                db.execute('INSERT INTO members(name) VALUES(?)', (name,))
                db.commit()
                flash('Member added.', 'success')
            except sqlite3.IntegrityError:
                flash('Member already exists.', 'warning')
        return redirect(url_for('members'))
    members = query(db, 'SELECT * FROM members ORDER BY name COLLATE NOCASE ASC')
    return render_template('attendees.html', club_name=CLUB_NAME, members=members, manage_global=True)

@app.route('/members/import', methods=['GET', 'POST'])
def import_members():
    db = get_db()
    if request.method == 'POST':
        file = request.files.get('csv_file')
        if not file or file.filename == '':
            flash('Please choose a CSV file.', 'danger')
            return redirect(url_for('import_members'))
        try:
            stream = TextIOWrapper(file.stream, encoding='utf-8')
            reader = csv.DictReader(stream)
            if 'name' not in reader.fieldnames:
                flash('CSV must include a "name" column.', 'danger')
                return redirect(url_for('import_members'))
            added = 0
            skipped = 0
            for row in reader:
                name = (row.get('name') or '').strip()
                if not name:
                    continue
                try:
                    db.execute('INSERT INTO members(name) VALUES(?)', (name,))
                    added += 1
                except sqlite3.IntegrityError:
                    skipped += 1
            db.commit()
            flash(f'Import complete. Added {added}, skipped {skipped} duplicate(s).', 'success')
            return redirect(url_for('members'))
        except UnicodeDecodeError:
            flash('Unable to read file. Please upload UTF-8 CSV.', 'danger')
            return redirect(url_for('import_members'))
    return render_template('import_members.html', club_name=CLUB_NAME)

@app.route('/members/<int:member_id>/delete', methods=['POST'])
def delete_member(member_id: int):
    db = get_db()
    db.execute('DELETE FROM members WHERE id = ?', (member_id,))
    db.commit()
    flash('Member deleted.', 'success')
    return redirect(url_for('members'))

# --- Attendees ---
@app.route('/event/<int:event_id>/attendees', methods=['GET', 'POST'])
def event_attendees(event_id: int):
    db = get_db()
    event = query(db, 'SELECT * FROM events WHERE id = ?', (event_id,), one=True)
    if not event:
        abort(404)
    if request.method == 'POST':
        selected_ids = set(request.form.getlist('member_id'))
        db.execute('DELETE FROM event_attendees WHERE event_id = ?', (event_id,))
        for mid in selected_ids:
            db.execute('INSERT OR IGNORE INTO event_attendees(event_id, member_id) VALUES(?, ?)', (event_id, mid))
        db.commit()
        flash('Attendees updated.', 'success')
        return redirect(url_for('event_overview', event_id=event_id))
    members = query(db, 'SELECT * FROM members ORDER BY name COLLATE NOCASE ASC')
    attending = set([row['member_id'] for row in query(db, 'SELECT member_id FROM event_attendees WHERE event_id = ?', (event_id,))])
    return render_template('attendees.html', club_name=CLUB_NAME, event=event, members=members, attending=attending, manage_global=False)

# --- Flights & Wines ---
@app.route('/event/<int:event_id>/flights', methods=['GET', 'POST'])
def event_flights(event_id: int):
    db = get_db()
    event = query(db, 'SELECT * FROM events WHERE id = ?', (event_id,), one=True)
    if not event:
        abort(404)
    if request.method == 'POST':
        existing_count = query(db, 'SELECT COUNT(*) c FROM flights WHERE event_id = ?', (event_id,), one=True)['c']
        if existing_count >= MAX_FLIGHTS_PER_EVENT:
            flash(f'Maximum of {MAX_FLIGHTS_PER_EVENT} flights reached.', 'warning')
            return redirect(url_for('event_flights', event_id=event_id))
        food = request.form.get('food', '').strip()
        next_seq = existing_count + 1
        db.execute('INSERT INTO flights(event_id, seq, food) VALUES (?, ?, ?)', (event_id, next_seq, food))
        db.commit()
        flash('Flight added.', 'success')
        return redirect(url_for('event_flights', event_id=event_id))
    flights = query(db, 'SELECT * FROM flights WHERE event_id = ? ORDER BY seq ASC', (event_id,))
    flight_wines = {}
    for f in flights:
        wines = query(db, 'SELECT * FROM wines WHERE flight_id = ? ORDER BY COALESCE(pour_seq, id) ASC', (f['id'],))
        flight_wines[f['id']] = wines
    return render_template('flights.html', club_name=CLUB_NAME, event=event, flights=flights, flight_wines=flight_wines, max_flights=MAX_FLIGHTS_PER_EVENT)

@app.route('/event/<int:event_id>/flights/<int:flight_id>/add_wine', methods=['POST'])
def add_wine(event_id: int, flight_id: int):
    db = get_db()
    flight = query(db, 'SELECT * FROM flights WHERE id = ? AND event_id = ?', (flight_id, event_id), one=True)
    if not flight:
        abort(404)
    name = request.form.get('wine_name', '').strip()
    producer = request.form.get('wine_producer', '').strip() or None
    vintage_raw = request.form.get('wine_vintage', '').strip()
    vintage = None
    if vintage_raw:
        try:
            vintage = int(vintage_raw)
        except ValueError:
            vintage = None
    if not name:
        flash('Wine name is required.', 'danger')
        return redirect(url_for('event_flights', event_id=event_id))
    db.execute('INSERT INTO wines(flight_id, name, producer, vintage) VALUES(?, ?, ?, ?)', (flight_id, name, producer, vintage))
    db.commit()
    flash('Wine added.', 'success')
    return redirect(url_for('event_flights', event_id=event_id))

@app.route('/event/<int:event_id>/flights/<int:flight_id>/randomize', methods=['POST'])
def randomize_pour_order(event_id: int, flight_id: int):
    db = get_db()
    f = query(db, 'SELECT * FROM flights WHERE id = ? AND event_id = ?', (flight_id, event_id), one=True)
    if not f:
        abort(404)
    wines = query(db, 'SELECT id FROM wines WHERE flight_id = ? ORDER BY id ASC', (flight_id,))
    ids = [w['id'] for w in wines]
    if len(ids) < 2:
        flash('Need at least 2 wines to randomize pour order.', 'warning')
        return redirect(url_for('event_flights', event_id=event_id))
    random.shuffle(ids)
    for idx, wine_id in enumerate(ids, start=1):
        db.execute('UPDATE wines SET pour_seq = ? WHERE id = ?', (idx, wine_id))
    db.commit()
    flash('Pour order randomized for this flight.', 'success')
    return redirect(url_for('event_flights', event_id=event_id))

@app.route('/event/<int:event_id>/flights/<int:flight_id>/delete', methods=['POST'])
def delete_flight(event_id: int, flight_id: int):
    db = get_db()
    db.execute('DELETE FROM flights WHERE id = ? AND event_id = ?', (flight_id, event_id))
    db.commit()
    flash('Flight deleted.', 'success')
    return redirect(url_for('event_flights', event_id=event_id))

@app.route('/event/<int:event_id>/wines/<int:wine_id>/delete', methods=['POST'])
def delete_wine(event_id: int, wine_id: int):
    db = get_db()
    w = query(db, 'SELECT w.id, f.event_id FROM wines w JOIN flights f ON f.id = w.flight_id WHERE w.id = ?', (wine_id,), one=True)
    if not w or w['event_id'] != event_id:
        abort(404)
    db.execute('DELETE FROM wines WHERE id = ?', (wine_id,))
    db.commit()
    flash('Wine deleted.', 'success')
    return redirect(url_for('event_flights', event_id=event_id))

# --- Scoring (Blind) ---
@app.route('/event/<int:event_id>/score/<int:flight_id>', methods=['GET', 'POST'])
def score_flight(event_id: int, flight_id: int):
    db = get_db()
    event = query(db, 'SELECT * FROM events WHERE id = ?', (event_id,), one=True)
    flight = query(db, 'SELECT * FROM flights WHERE id = ? AND event_id = ?', (flight_id, event_id), one=True)
    if not event or not flight:
        abort(404)
    attendees = query(db, (
        'SELECT m.* FROM members m '
        'JOIN event_attendees ea ON ea.member_id = m.id '
        'WHERE ea.event_id = ? ORDER BY m.name COLLATE NOCASE ASC'
    ), (event_id,))
    wines = query(db, 'SELECT * FROM wines WHERE flight_id = ? ORDER BY COALESCE(pour_seq, id) ASC', (flight_id,))
    if request.method == 'POST':
        updated = 0
        for m in attendees:
            for w in wines:
                sf = f"score-{m['id']}-{w['id']}"
                cf = f"comment-{m['id']}-{w['id']}"
                raw_score = request.form.get(sf)
                raw_comment = request.form.get(cf, '').strip()
                score_val = None
                if raw_score is not None and raw_score.strip() != '':
                    try:
                        score_val = int(raw_score)
                    except ValueError:
                        score_val = None
                if score_val is not None and 1 <= score_val <= 10:
                    comment_val = raw_comment if raw_comment else None
                    try:
                        db.execute("""
                            INSERT INTO scores(event_id, flight_id, wine_id, member_id, score, comment)
                            VALUES (?, ?, ?, ?, ?, ?)
                            ON CONFLICT(wine_id, member_id) DO UPDATE SET score = excluded.score, comment = excluded.comment
                        """, (event_id, flight_id, w['id'], m['id'], score_val, comment_val))
                        updated += 1
                    except sqlite3.IntegrityError:
                        pass
        db.commit()
        flash(f'Saved {updated} score(s).', 'success')
        return redirect(url_for('score_flight', event_id=event_id, flight_id=flight_id))
    scores_raw = query(db, 'SELECT * FROM scores WHERE flight_id = ?', (flight_id,))
    scores_map = {(r['member_id'], r['wine_id']): r['score'] for r in scores_raw}
    comments_map = {(r['member_id'], r['wine_id']): (r['comment'] or '') for r in scores_raw}
    return render_template('score_flight.html', club_name=CLUB_NAME, event=event, flight=flight, attendees=attendees, wines=wines, scores=scores_map, comments=comments_map)

# --- Results (Full details) ---
@app.route('/event/<int:event_id>/results')
def event_results(event_id: int):
    db = get_db()
    event = query(db, 'SELECT * FROM events WHERE id = ?', (event_id,), one=True)
    if not event:
        abort(404)
    flights = query(db, 'SELECT * FROM flights WHERE event_id = ? ORDER BY seq ASC', (event_id,))
    results = []
    for f in flights:
        wines = query(db, 'SELECT * FROM wines WHERE flight_id = ? ORDER BY COALESCE(pour_seq, id) ASC', (f['id'],))
        rows = []
        for w in wines:
            agg = query(db, 'SELECT COUNT(*) as n, SUM(score) as total, AVG(score) as avg FROM scores WHERE wine_id = ?', (w['id'],), one=True)
            n = agg['n'] or 0
            total = int(agg['total']) if agg['total'] is not None else 0
            avg = round(agg['avg'], 2) if agg['avg'] is not None else 0.0
            comments = query(db, (
                'SELECT m.name as member_name, s.comment FROM scores s '
                'JOIN members m ON m.id = s.member_id '
                'WHERE s.wine_id = ? AND s.comment IS NOT NULL AND TRIM(s.comment) <> "" '
                'ORDER BY m.name COLLATE NOCASE ASC'
            ), (w['id'],))
            rows.append({'wine': w, 'n': n, 'total': total, 'avg': avg, 'comments': comments})
        rows.sort(key=lambda r: (r['total'], r['avg']), reverse=True)
        results.append({'flight': f, 'rows': rows})
    return render_template('results.html', club_name=CLUB_NAME, event=event, results=results)

@app.route('/event/<int:event_id>/results/print')
def event_results_print(event_id: int):
    db = get_db()
    event = query(db, 'SELECT * FROM events WHERE id = ?', (event_id,), one=True)
    if not event:
        abort(404)
    flights = query(db, 'SELECT * FROM flights WHERE event_id = ? ORDER BY seq ASC', (event_id,))
    results = []
    for f in flights:
        wines = query(db, 'SELECT * FROM wines WHERE flight_id = ? ORDER BY COALESCE(pour_seq, id) ASC', (f['id'],))
        rows = []
        for w in wines:
            agg = query(db, 'SELECT COUNT(*) as n, SUM(score) as total, AVG(score) as avg FROM scores WHERE wine_id = ?', (w['id'],), one=True)
            n = agg['n'] or 0
            total = int(agg['total']) if agg['total'] is not None else 0
            avg = round(agg['avg'], 2) if agg['avg'] is not None else 0.0
            rows.append({'wine': w, 'n': n, 'total': total, 'avg': avg})
        rows.sort(key=lambda r: (r['total'], r['avg']), reverse=True)
        results.append({'flight': f, 'rows': rows})
    return render_template('results_print.html', club_name=CLUB_NAME, event=event, results=results)

if __name__ == '__main__':
    # For local run; on Render we use gunicorn via Procfile/startCommand
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=False)
