
# The Monday Table – Wine Tasting Club App (v4)

**New in v4**
- **Producer** added to wine metadata (alongside **name** and **vintage**).
- All admin lists and results now display **Producer – Name (Vintage)**.

**Since v3**
- Blind tasting: randomize pour order; scoring hides wine details (shows Wine #1, #2, …); results reveal all details.
- Print-friendly results view.

**Since v2**
- Comments per wine (per member)
- Member CSV import

## Quick Start
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
export FLASK_APP=app.py        # Windows PowerShell: $Env:FLASK_APP = "app.py"
flask run
```
Open http://127.0.0.1:5000

## Database & Migrations
- DB file: `instance/monday_table.db`
- Auto-migrations on startup ensure:
  - `scores.comment` (v2)
  - `wines.vintage`, `wines.pour_seq` (v3)
  - `wines.producer` (v4)

## Tips
- Use **Flights → Randomize pour order** after adding wines to a flight to enable blind scoring.
- Use **Results → Print-friendly view** for a clean printout.

